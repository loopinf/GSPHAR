# -*- coding: utf-8 -*-
"""
Created on Mon Oct 7 2024

@author: MC
"""

import argparse
import numpy as np
import pandas as pd
from scipy.linalg import sqrtm
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
import statsmodels.api as sm
import utils as utils
import yaml
import sys
import warnings
import pygsp as gsp
warnings.filterwarnings('ignore')

### Training
def load_yaml(file_path):
    """Loads a YAML file and returns the contents as a dictionary."""
    with open(file_path, 'r') as file:
        try:
            config = yaml.safe_load(file)
            return config
        except yaml.YAMLError as exc:
            print(f"Error loading YAML file: {exc}")
            sys.exit(1)

def load_dataset(dataset_path):
    """Loads a dataset given the path."""
    try:
        dataset = pd.read_csv(dataset_path, index_col = 0)*100
        return dataset
    except Exception as e:
        print(f"Error loading dataset: {e}")
        sys.exit(1)
        
def data_split(data, proportion):
    date_list = data.index.tolist()
    train_end_idx = int(len(date_list)*proportion)
    train_dataset = data.iloc[0:train_end_idx,:]
    test_dataset = data.iloc[train_end_idx:,:]
    return train_dataset, test_dataset

class v_GSPHAR:
    def __init__(self, adj_mx):
        """Initializes the model by computing the normalized Laplacian and Fourier basis."""
        # Eigendecomposition of the adjacency matrix
        A = (adj_mx - adj_mx.T)
        A[A < 0] = 0
        A = A + np.eye(A.shape[0]) * 1e-8
        D = np.diag(np.sum(A, axis=1))
        D_inv = np.linalg.inv(D)
        D_inv_sqrt = sqrtm(D_inv)
        A_norm = D_inv_sqrt @ A @ D_inv_sqrt
        
        # Graph creation and Fourier basis computation
        self.graph = gsp.graphs.Graph(A_norm)
        self.graph.compute_fourier_basis()
        
        # Extract Laplacian and Fourier basis
        self.L = self.graph.L.todense()
        self.U = self.graph.U
        
        # Store parameters for later use
        self.params_df = None

    def gft(self, dataset):
        """Performs the Graph Fourier Transform (GFT) on the dataset."""
        return self.U.T @ dataset.values.T

    def igft(self, spectral_data):
        """Performs the Inverse Graph Fourier Transform (IGFT) on the spectral data."""
        return self.U @ spectral_data

    def train(self, train_dataset):
        """Trains the GSPHAR model by fitting an OLS regression to the transformed data."""
        # GFT on training dataset
        train_dataset_spectral_val = self.gft(train_dataset)
        train_dataset_spectral_df = pd.DataFrame(data=train_dataset_spectral_val.T, 
                                                 index=train_dataset.index, 
                                                 columns=train_dataset.columns)
        
        # Prepare parameters DataFrame
        market_indices_list = train_dataset.columns.tolist()
        self.params_df = pd.DataFrame(index=['const', 'RV_lag1', 'RV_weekly', 'RV_monthly'], 
                                      columns=market_indices_list)
        
        # Train model for each market index
        for market_indices in market_indices_list:
            rv_full_array = train_dataset_spectral_df[market_indices].values
            rv_trading_array = rv_full_array
            
            # Prepare training data
            rv_df = pd.DataFrame(rv_trading_array, columns=['rv'])
            rv_df['RV_daily'] = rv_df['rv'].shift(1)
            rv_df['RV_weekly'] = rv_df['rv'].rolling(window=5).mean().shift(1)
            rv_df['RV_monthly'] = rv_df['rv'].rolling(window=22).mean().shift(1)
            rv_df = rv_df.dropna()
            
            # OLS regression
            X = rv_df[['RV_daily', 'RV_weekly', 'RV_monthly']]
            X = sm.add_constant(X)  # Adds a constant term to the predictor
            y = rv_df['rv']
            model = sm.OLS(y, X).fit()
            params_array = model.params.values
            self.params_df[market_indices] = params_array

    def test(self, test_dataset):
        """Tests the GSPHAR model by forecasting and evaluating on the test dataset."""
        if self.params_df is None:
            raise ValueError("The model has not been trained yet. Please call the Training method first.")
        
        # GFT on testing dataset
        test_dataset_spectral_val = self.gft(test_dataset)
        test_dataset_spectral_df = pd.DataFrame(data=test_dataset_spectral_val.T, 
                                                index=test_dataset.index, 
                                                columns=test_dataset.columns)
        
        # Initialize dictionaries for predictions
        pred_dict = {}
        rv_hat_dict = {}
        
        market_indices_list = test_dataset.columns.tolist()
        
        # Forecast for each market index
        for market_indices in market_indices_list:
            rv_full_array = test_dataset_spectral_df[market_indices].values
            rv_trading_array = rv_full_array
            
            # Prepare testing data
            rv_df = pd.DataFrame(rv_trading_array, columns=['rv'])
            rv_df['RV_daily'] = rv_df['rv'].shift(1)
            rv_df['RV_weekly'] = rv_df['rv'].rolling(window=5).mean().shift(1)
            rv_df['RV_monthly'] = rv_df['rv'].rolling(window=22).mean().shift(1)
            rv_df = rv_df.dropna()
            
            # Get parameters from training
            params_array = self.params_df[market_indices].values
            X = rv_df[['RV_daily', 'RV_weekly', 'RV_monthly']].values
            const_column = np.ones((X.shape[0], 1))
            X_const = np.hstack((const_column, X))
            
            # Forecast
            rv_hat = X_const @ params_array
            pred_dict[market_indices + '_rv_true'] = test_dataset[market_indices].iloc[rv_df.index].values
            rv_hat_dict[market_indices + '_rv_forecast'] = rv_hat
        
        # Stack the forecasts
        num_rows = len(rv_hat_dict.keys())
        num_cols = len(rv_hat_dict[list(rv_hat_dict.keys())[0]])
        stacked_rv_hat_spectral = np.zeros((num_rows, num_cols))
        
        for i, (key, value) in enumerate(rv_hat_dict.items()):
            stacked_rv_hat_spectral[i, :] = value.reshape(1, -1)
        
        # Inverse GFT
        stacked_rv_hat_spatial = self.igft(stacked_rv_hat_spectral)
        
        # Prepare final predictions
        for i, market_indices in enumerate(market_indices_list):
            pred_dict[market_indices + '_rv_forecast'] = stacked_rv_hat_spatial[i, :]
        
        pred_df = pd.DataFrame(pred_dict)
        return pred_df

class GSPHAR_Dataset(Dataset):
    def __init__(self, dict):
        self.dict = dict

    def __len__(self):
        return len(self.dict.keys())

    def __getitem__(self, idx):
        date = list(self.dict.keys())[idx]
        dfs_dict = self.dict[date]
        y = dfs_dict['y'].values
        x_lag1 = dfs_dict['x_lag1'].values
        x_lag5 = dfs_dict['x_lag5'].values
        x_lag22 = dfs_dict['x_lag22'].values
        
        y_tensor = torch.tensor(y, dtype=torch.float32)
        x_lag1_tensor = torch.tensor(x_lag1, dtype=torch.float32)
        x_lag5_tensor = torch.tensor(x_lag5, dtype=torch.float32)
        x_lag22_tensor = torch.tensor(x_lag22, dtype=torch.float32)
        return x_lag1_tensor, x_lag5_tensor, x_lag22_tensor, y_tensor

class GSPHAR(nn.Module):
    # linear transformation
    def __init__ (self, input_dim, output_dim, filter_size, U, U_dega):
        super(GSPHAR,self).__init__()
        self.U = torch.complex(torch.tensor(U.real, dtype=torch.float32), torch.tensor(U.imag, dtype=torch.float32))
        self.U_dega = torch.complex(torch.tensor(U_dega.real, dtype=torch.float32), torch.tensor(U_dega.imag, dtype=torch.float32))
        self.conv1d_lag5 = nn.Conv1d(in_channels = filter_size, out_channels = filter_size, kernel_size = 5, groups = filter_size, bias = False) # groups=1 markets share similarity
        nn.init.constant_(self.conv1d_lag5.weight, 1.0 / 5)
        self.conv1d_lag22 = nn.Conv1d(in_channels = filter_size, out_channels = filter_size, kernel_size = 22, groups = filter_size, bias = False) # groups=1
        nn.init.constant_(self.conv1d_lag22.weight, 1.0 / 22)
        self.spatial_process = nn.Sequential(
            nn.Linear(2, 2 * 8),
            nn.ReLU(),
            nn.Linear(2 * 8, 2 * 8),
            nn.ReLU(),
            nn.Linear(2 * 8, 1),
            nn.ReLU()
        )
        self.linear_output = nn.Linear(input_dim, output_dim, bias=True)
        
    def forward(self, x_lag1, x_lag5, x_lag22):
        # Ensure all items are on the same device as the input x
        device = x_lag1.device
        U = self.U.to(device)
        U_dega = self.U_dega.to(device)
        self.conv1d_lag5 = self.conv1d_lag5.to(device)
        self.conv1d_lag22 = self.conv1d_lag22.to(device)
        self.spatial_process = self.spatial_process.to(device)
        self.linear_output_real = self.linear_output.to(device)
        self.linear_output_imag = self.linear_output.to(device)
    
        # Convert RV to complex domain
        x_lag1 = torch.complex(x_lag1, torch.zeros_like(x_lag1))
        x_lag5 = torch.complex(x_lag5, torch.zeros_like(x_lag5))
        x_lag22 = torch.complex(x_lag22, torch.zeros_like(x_lag22))

        # Spectral domain operations on lag-5
        x_lag5 = torch.matmul(U_dega, x_lag5)
        exp_param_5 = torch.exp(self.conv1d_lag5.weight)
        sum_exp_param_5 = torch.sum(exp_param_5, dim=-1, keepdim=True)
        softmax_param_5 = exp_param_5/sum_exp_param_5
        x_lag5_real = F.conv1d(input=x_lag5.real, weight=softmax_param_5, bias=None, groups=24)
        x_lag5_imag = F.conv1d(input=x_lag5.imag, weight=softmax_param_5, bias=None, groups=24)
        x_lag5 = torch.complex(x_lag5_real, x_lag5_imag)
        x_lag5 = x_lag5.squeeze(-1)

        # Spectral domain operations on lag-22
        x_lag22 = torch.matmul(U_dega, x_lag22)
        exp_param_22 = torch.exp(self.conv1d_lag22.weight)
        sum_exp_param_22 = torch.sum(exp_param_22, dim=-1, keepdim=True)
        softmax_param_22 = exp_param_22/sum_exp_param_22
        x_lag22_real = F.conv1d(input=x_lag22.real, weight=softmax_param_22, bias=None, groups=24)
        x_lag22_imag = F.conv1d(input=x_lag22.imag, weight=softmax_param_22, bias=None, groups=24)
        x_lag22 = torch.complex(x_lag22_real, x_lag22_imag)
        x_lag22 = x_lag22.squeeze(-1)

        # Lag-1 processing
        x_lag1 = torch.matmul(U_dega, x_lag1.unsqueeze(-1))
        x_lag1 = x_lag1.squeeze(-1)

        # Combine lagged responses in the spectral domain
        lagged_rv_spectral = torch.stack((x_lag1, x_lag5, x_lag22), dim=-1)
        
        # Apply linear transformation separately to the real and imaginary parts
        y_hat_real = self.linear_output_real(lagged_rv_spectral.real)
        y_hat_imag = self.linear_output_imag(lagged_rv_spectral.imag)
        y_hat_spectral = torch.complex(y_hat_real, y_hat_imag)

        # Back to the spatial domain
        y_hat = torch.matmul(U, y_hat_spectral)

        y_hat_real = y_hat.real # [batch_size, num_markets, 1]
        y_hat_imag = y_hat.imag # [batch_size, num_markets, 1]
        y_hat_real = y_hat_real.squeeze(-1)
        y_hat_imag = y_hat_imag.squeeze(-1)
        
        y_hat_spatial = torch.stack((y_hat_real, y_hat_imag), dim=-1)
        
        # Apply linear transformation separately to the real and imaginary parts
        y_hat = self.spatial_process(y_hat_spatial)
        
        return y_hat.squeeze(-1), softmax_param_5, softmax_param_22

def main():
    ### Initialization
    torch.manual_seed(42)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(42)
        torch.cuda.manual_seed_all(42)  # if using multi-GPU
    # Create argument parser
    parser = argparse.ArgumentParser()
    # Define arguments
    parser.add_argument('--config_filename', default = 'config/GSPHAR_config.yaml', type=str, help="Path to the YAML configuration file.")
    # Parse the arguments
    args = parser.parse_args()
    # Load the YAML configuration file using the --config argument
    config = load_yaml(args.config_filename)
    # Load dataset
    dataset_path = config['dataset']['path']
    dataset = load_dataset(dataset_path)
    train_dataset, test_dataset = data_split(dataset, 0.7)
    
    ### Graph formulation
    spillover_graph = utils.compute_spillover_index(train_dataset, 1, 22, 0.0, standardized=True)
    
    ### v-GSPHAR
    v_GSPHAR_model = v_GSPHAR(spillover_graph)
    v_GSPHAR_model.train(train_dataset)

    
    ### GSPHAR
    # Create dataset and dataloader
    train_dict, test_dict = utils.GSPHAR_dataprep(train_dataset, test_dataset)
    dataset_train = GSPHAR_Dataset(train_dict)
    dataset_test = GSPHAR_Dataset(test_dict)
    dataloader_train = DataLoader(dataset_train, batch_size=32, shuffle=True)
    dataloader_test = DataLoader(dataset_test, batch_size=32, shuffle=False)
    # magnet Laplacian eigendecomposition
    Lambda, U_dega, U = utils.eigendecomposition_laplacian(spillover_graph)
    # Train and evaluate model
    input_dim = 3
    output_dim = 1
    filter_size = 24
    num_epochs = 100
    lr = 0.01
    GSPHAR_RV = GSPHAR(input_dim,output_dim, filter_size, U, U_dega)
    valid_loss, final_conv1d_lag5_weights, final_conv1d_lag22_weights = utils.train_eval_model(GSPHAR_RV, dataloader_train, dataloader_test, num_epochs, lr)
    trained_GSPHAR, _  = utils.load_model('GSPHAR_24_magnet',GSPHAR_RV)

if __name__ == '__main__':
    main()
    