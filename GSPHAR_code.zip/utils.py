# -*- coding: utf-8 -*-
"""
Created on Mon Oct  7 16:01:48 2024

@author: MC
"""

import os
import numpy as np
from scipy.linalg import sqrtm
np.random.seed(0)
from scipy.linalg import eig
import pandas as pd
import torch
import torch.nn as nn
from statsmodels.tsa.api import VAR
import warnings
warnings.filterwarnings('ignore')


def compute_spillover_index(data, horizon, lag, scarcity_prop, standardized=True):

    data_array = data.values

    model = VAR(data_array)
    results = model.fit(maxlags=lag)

    Sigma = results.sigma_u
    A = results.orth_ma_rep(maxn=horizon - 1)
    
    Sigma_A = []
    A_Sigma_A = []
    
    for h in range(horizon):
        Sigma_A_h = (A[h] @ Sigma @ np.linalg.inv(np.diag(np.sqrt(np.diag(Sigma))))) ** 2
        Sigma_A.append(Sigma_A_h)
        
        A_Sigma_A_h = A[h] @ Sigma @ A[h].T
        A_Sigma_A.append(A_Sigma_A_h)
    
    num = np.cumsum(Sigma_A, axis=0)
    
    den = np.cumsum(A_Sigma_A, axis=0)
    
    gfevd = np.array([num[h] / np.diag(den[h])[:, None] for h in range(horizon)])
    
    if standardized:
        gfevd = np.array([fevd / fevd.sum(axis=1, keepdims=True) for fevd in gfevd])
    
    spillover_matrix = gfevd[-1]
    
    spillover_matrix = spillover_matrix.T
    
    spillover_matrix *= 100      
    
    K = spillover_matrix.shape[0]
    
    results_df = pd.DataFrame(spillover_matrix, columns=results.names, index=results.names)
    
    vsp_df_sparse = results_df.copy()
    threshold = pd.Series(results_df.values.flatten()).quantile(scarcity_prop)
    vsp_df_sparse[vsp_df_sparse < threshold] = 0
    vsp_np_sparse = vsp_df_sparse.values
    np.fill_diagonal(vsp_np_sparse, 0)

    if standardized:
        vsp_np_sparse = vsp_np_sparse / K
        return vsp_np_sparse
    else:
        return vsp_np_sparse
    
def magnet_laplacian(A, q, norm = True):
    A_s = (A + A.T)/2
    D_s = np.diag(np.sum(A_s, axis=1))
    pi = np.pi
    theta_q = 2 * pi * q * (A - A.T)
    H_q = A_s * np.exp(1j*theta_q)
    if norm == True:
        D_s_inv = np.linalg.inv(D_s)
        D_s_inv_sqrt = sqrtm(D_s_inv)
        L = np.eye(len(D_s)) - (D_s_inv_sqrt @ A_s @ D_s_inv_sqrt) * np.exp(1j*theta_q)
    else:
        L = D_s - H_q

    return L

def eigendecomposition_laplacian(L):
    eigenvalues, eigenvectors = eig(L)
    # eigenvectors is the right eigenvectors of L
    Lambda = eigenvalues.real
    U_dega = eigenvectors
    U = eigenvectors.T.conj()
    
    # Sort the eigenvalues (Lambda) and get the indices of the sorted order
    sorted_indices = np.argsort(Lambda)  # Sort in ascending order
    
    # Reorder Lambda, U, and U_dega
    Lambda_sorted = Lambda[sorted_indices]  
    U_sorted = U[:, sorted_indices]   
    U_dega_sorted = U_dega[sorted_indices, :] 
    
    # Convert sorted Sigma into a diagonal matrix
    Lambda_matrix_sorted = np.diag(Lambda_sorted)
    Lambda = Lambda_matrix_sorted
    U_dega = U_dega_sorted
    U = U_sorted
    return Lambda, U_dega, U

def save_model(name, model, best_loss_val = None):
    if not os.path.exists('models/'):
            os.makedirs('models/')
    # Prepare the model state dictionary
    config = {
        'model_state_dict': model.state_dict(),
        'loss': best_loss_val
    }
    # Save the model state dictionary
    torch.save(config, f'models/{name}.tar')
    return

def load_model(name, model):
    checkpoint = torch.load(f'models/{name}.tar', map_location='cpu')
    model.load_state_dict(checkpoint['model_state_dict'])
    mae_loss = checkpoint['loss']
    print(f"Loaded model: {name}")
    return model, mae_loss

def GSPHAR_dataprep(train_dataset, test_dataset):
    look_back_window = 22
    market_indices_list = train_dataset.columns.tolist()
    for market_index in market_indices_list:
        for lag in range(look_back_window):
            train_dataset[market_index + f'_{lag+1}'] = train_dataset[market_index].shift(lag+1)
            test_dataset[market_index + f'_{lag+1}'] = test_dataset[market_index].shift(lag+1)
    
    train_dataset = train_dataset.dropna()
    test_dataset = test_dataset.dropna()
    columns_lag1 = [x for x in train_dataset.columns.tolist() if x[-2:] == '_1']
    columns_lag5 = [x for x in train_dataset.columns.tolist() if (x[-2]=='_') and (float(x[-1]) in range(1,6))]
    columns_lag22 = [x for x in train_dataset.columns.tolist() if '_' in x]
    # columns_lag22 = [x for x in columns_lag22_1 if (x not in columns_lag1) and (x not in (columns_lag5))]
    x_columns = columns_lag1 + columns_lag5 + columns_lag22
    y_columns = [x for x in train_dataset.columns.tolist() if x not in x_columns]
    row_index_order = market_indices_list
    column_index_order_5 = [f'lag_{i}' for i in range(1,6)]
    column_index_order_22 = [f'lag_{i}' for i in range(1,23)]
    
    
    train_dict = {}
    for date in train_dataset.index:
        y = train_dataset.loc[date,y_columns]
        
        x_lag1 = train_dataset.loc[date,columns_lag1]
        new_index = [ind[:-2] for ind in x_lag1.index.tolist()]
        x_lag1.index = new_index
        
        x_lag5 = train_dataset.loc[date,columns_lag5]
    
        # Split the index into market indices and lags
        data_lag5 = {
        'Market': [index.split('_')[0] for index in x_lag5.index],
        'Lag': [f'lag_{index.split("_")[1]}' for index in x_lag5.index],
        'Value': x_lag5.values
        }
        # Convert to DataFrame
        df_lag5 = pd.DataFrame(data_lag5)
        # Pivot the DataFrame
        df_lag5 = df_lag5.pivot(index='Market', columns='Lag', values='Value')
    
        x_lag22 = train_dataset.loc[date,columns_lag22]
        # Split the index into market indices and lags
        data_lag22 = {
        'Market': [index.split('_')[0] for index in x_lag22.index],
        'Lag': [f'lag_{index.split("_")[1]}' for index in x_lag22.index],
        'Value': x_lag22.values
        }
        # Convert to DataFrame
        df_lag22 = pd.DataFrame(data_lag22)
        # Pivot the DataFrame
        df_lag22 = df_lag22.pivot(index='Market', columns='Lag', values='Value')
    
        x_lag1 = x_lag1.reindex(row_index_order)
        df_lag5 = df_lag5.reindex(row_index_order)
        df_lag22= df_lag22.reindex(row_index_order)
        df_lag5 = df_lag5[column_index_order_5]
        df_lag22 = df_lag22[column_index_order_22]
        
        dfs_dict = {
            'y': y,
            'x_lag1': x_lag1,
            'x_lag5': df_lag5,
            'x_lag22': df_lag22
        }
        train_dict[date] = dfs_dict
    
    test_dict = {}
    for date in test_dataset.index:
        y = test_dataset.loc[date,y_columns]
        
        x_lag1 = test_dataset.loc[date,columns_lag1]
        new_index = [ind[:-2] for ind in x_lag1.index.tolist()]
        x_lag1.index = new_index
        
        x_lag5 = test_dataset.loc[date,columns_lag5]
        # Split the index into market indices and lags
        data_lag5 = {
        'Market': [index.split('_')[0] for index in x_lag5.index],
        'Lag': [f'lag_{index.split("_")[1]}' for index in x_lag5.index],
        'Value': x_lag5.values
        }
        # Convert to DataFrame
        df_lag5 = pd.DataFrame(data_lag5)
        # Pivot the DataFrame
        df_lag5 = df_lag5.pivot(index='Market', columns='Lag', values='Value')
    
        x_lag22 = test_dataset.loc[date,columns_lag22]
        # Split the index into market indices and lags
        data_lag22 = {
        'Market': [index.split('_')[0] for index in x_lag22.index],
        'Lag': [f'lag_{index.split("_")[1]}' for index in x_lag22.index],
        'Value': x_lag22.values
        }
        # Convert to DataFrame
        df_lag22 = pd.DataFrame(data_lag22)
        # Pivot the DataFrame
        df_lag22 = df_lag22.pivot(index='Market', columns='Lag', values='Value')
    
        x_lag1 = x_lag1.reindex(row_index_order)
        df_lag5 = df_lag5.reindex(row_index_order)
        df_lag22= df_lag22.reindex(row_index_order)
        df_lag5 = df_lag5[column_index_order_5]
        df_lag22 = df_lag22[column_index_order_22]
        
        dfs_dict = {
            'y': y,
            'x_lag1': x_lag1,
            'x_lag5': df_lag5,
            'x_lag22': df_lag22
        }
        test_dict[date] = dfs_dict
        return train_dict, test_dict

def train_eval_model(model, dataloader_train, dataloader_test, num_epochs = 200, lr = 0.01):
    best_loss_val = 1000000
    patience = 0
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.OneCycleLR(optimizer, max_lr = lr, 
                                                   steps_per_epoch=len(dataloader_train), epochs = num_epochs,
                                                   three_phase=True)
    model.to(device)
    criterion = nn.MSELoss()
    criterion = criterion.to(device)
    model.train()
    for epoch in range(num_epochs):
        for x_lag1, x_lag5, x_lag22, y in dataloader_train:
            x_lag1 = x_lag1.to(device)
            x_lag5 = x_lag5.to(device)
            x_lag22 = x_lag22.to(device)
            y = y.to(device)
            optimizer.zero_grad()
            output, conv1d_lag5_weights, conv1d_lag22_weights = model(x_lag1, x_lag5, x_lag22)
            loss = criterion(output, y)
            loss.backward()
            
            # Update parameters
            optimizer.step()
            
            # Update scheduler: this scheduler is designed to be updated after each batch.
            scheduler.step()
        
        # Evaluate model
        valid_loss = evaluate_model(model, dataloader_test)

        if valid_loss < best_loss_val:
            best_loss_val = valid_loss
            final_conv1d_lag5_weights = conv1d_lag5_weights.detach().cpu().numpy()
            final_conv1d_lag22_weights = conv1d_lag22_weights.detach().cpu().numpy()
            patience = 0
            save_model('GSPHAR_24_magnet', model, best_loss_val)
        else:
            patience = patience + 1
            if patience >= 50:
                print(f'early stopping at epoch {epoch+1}.')
                break
            else:
                pass
    return best_loss_val, final_conv1d_lag5_weights, final_conv1d_lag22_weights


# Evaluate model
def evaluate_model(model, dataloader_test):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)
    criterion = nn.L1Loss()
    criterion = criterion.to(device)
    valid_loss = 0
    model.eval()
    with torch.no_grad():
        for x_lag1, x_lag5, x_lag22, y in dataloader_test:
            x_lag1 = x_lag1.to(device)
            x_lag5 = x_lag5.to(device)
            x_lag22 = x_lag22.to(device)
            y = y.to(device)
            output, _, _ = model(x_lag1, x_lag5, x_lag22)
            loss = criterion(output, y)
            valid_loss = valid_loss + loss.item()
    valid_loss = valid_loss/len(dataloader_test)
    return valid_loss